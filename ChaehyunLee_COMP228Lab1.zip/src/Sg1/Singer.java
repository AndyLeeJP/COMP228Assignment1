package Sg1;



public class Singer{
	int singerId;
	String singerName;
	String singerAddress;
	String singerBirthDay;
	int numberOfAlbum;

	public Singer(){
		
	} 
	
	public Singer(String theirName, int id, String address, String birthDay, int album){
		singerName = theirName; 
		singerId = id;
		singerAddress = address;
		singerBirthDay = birthDay;
		numberOfAlbum = album;
		}
	
	public void setSinger(String theirName, int id, String address, String birthDay, int album) {
		singerName = theirName; 
		singerId = id;
		singerAddress = address;
		singerBirthDay = birthDay;
		numberOfAlbum = album;
	}
	
	public String getName(){
		return singerName;
		}
	public int getId(){
		return singerId;
		}
	public String getAddress(){
		return singerAddress;
		}
	public String getBirthDay(){
		return singerBirthDay;
		}
	public int getAlbum(){
		return numberOfAlbum;
		}
	
//	public String toString() {
//		return "\nthe singer's name is : "+singerName+"\nthe singer's ID is :"+singerId+"\nthe singer's Address is : "+singerAddress+"\nthe singer's Birth Day is :"+singerBirthDay+"\nthe singer's Number of Albums are :"+numberOfAlbum;
//	}
	
	public static void main(String[] args){
		
		Singer singer1 = new Singer();
//		Singer dataOfSinger = new Singer();
//		Singer dataOfId = new Singer();
//		Singer dataOfAdress = new Singer();
//		Singer dataOfBirthDay = new Singer();
//		Singer dataOfAlbum = new Singer();
		
		singer1.singerName = "Sum41";
		singer1.singerId = 1234;
		singer1.singerAddress = "Canada";
		singer1.singerBirthDay = "Octobver, 24";
		singer1.numberOfAlbum = 5;
		
		

		System.out.println("the singer's name is : " + singer1.getName());
		System.out.println("the singer's ID is : " + singer1.getId());
		System.out.println("the singer's Adress is : " + singer1.getAddress());
		System.out.println("the singer's Birth Day is : " + singer1.getBirthDay());
		System.out.println("the singer's Number of Albums are : " + singer1.getAlbum());
		}
}  
